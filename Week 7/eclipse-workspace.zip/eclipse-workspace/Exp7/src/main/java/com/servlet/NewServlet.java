package com.servlet;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(name="NewServlet",urlPatterns = {"/NewServlet"})
public class NewServlet extends HttpServlet{
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
		response.setContentType("text/html");
		String foo = request.getParameter("inTxtBox");
		PrintWriter obj = response.getWriter();
		String col = request.getParameter("ouTxtBox");
		obj.println("<font color="+col+">");
		obj.println("<h1>welcome "+foo+"</h1>");
		obj.println("</font>");
		obj.close();
		}
}
